//abrir conta e depositar
public class Cliente;
public String JOptionPane.showInputDialog